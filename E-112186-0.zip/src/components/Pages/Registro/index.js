import Registro from './Registro';
export default Registro;