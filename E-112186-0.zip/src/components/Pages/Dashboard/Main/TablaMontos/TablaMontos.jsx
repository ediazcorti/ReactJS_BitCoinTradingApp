import React, { useEffect } from "react";
import TableItemRow from "../Table/TableItemRow";
import { useSelector, useDispatch } from "react-redux";
import transactionSlice from "../../../../../app/slices/transactionSlice";
import coinSlice from "../../../../../app/slices/coinSlice";
import { useState } from "react";
import { setToLocalStorage, getFromLocalStorage } from "../../../../../utils/storage";

const TablaMontos = () => {
    const transacciones = useSelector((state) => state.transactions.transactions);
    const monedas = useSelector((state) => state.coin)
    const dispatch = useDispatch()

    let listaCompras = []
    let listaVentas = []
    //  let montoTotalCompras1 = 0
    let localMontoFinal = getFromLocalStorage("montoTotal")
    let localmontoCompras = getFromLocalStorage("montoCompras")
    let localmontoVentas = getFromLocalStorage("montoVentas")
    // useEffect(() => {



    //         },[])



    // 1. UseState de montoTotalCompras y Ventas y Total
    const [montoTotalC, setMontoTotalC] = useState(localmontoCompras);
    const [montoTotalV, setMontoTotalV] = useState(localmontoVentas);
    const [montoTotalFinal, setMontoTotalFinal] = useState(localMontoFinal);
    // 2. Funcion para Setear el montoTotalCompras

    const setearMontoCompras = (a) => {
        setMontoTotalC(a)
        console.log("RECIBI ESTE RESULTADO EN COMPRAS")
        console.log(montoTotalC)
    }

    const setearMontoVentas = (a) => {
        console.log(montoTotalV)
        setMontoTotalV(a)
        console.log("RECIBI ESTE RESULTADO EN VENTAS")
        console.log(montoTotalV)
    }

    const setearMontoTotal = (a) => {
        setMontoTotalFinal(a)
        console.log("RECIBI ESTE RESULTADO EN TOTAL")
        console.log(montoTotalFinal)
    }

    //    const initialValue = 0;
    // const montoTotalCompras = listaCompras.reduce(
    //   (previousValue, currentValue) => previousValue + currentValue,
    //   initialValue
    // );

    // Object.keys(data).reduce

    const obtenerMontoCompras = () => {
        // const response2 = await ObtenerTransacciones(user.id)
        //      dispatch(setTransacciones(response2.transacciones))
        // console.log("Valor de cada compra ============> ")
        // listaCompras.map((compra) =>  console.log(compra.cantidad * compra.valor_actual))

        // filter((transaction) => transaction.tipo_operacion == 1 ? listaCompras.push(transaction) : null)

        let montoTotalCompras = listaCompras.reduce((acumulado, compra) => acumulado + (
            compra.cantidad * compra.valor_actual)

            , 0);
        console.log("El monto  total de compras es:___________________")
        //  console.log(montoTotalCompras)
        setearMontoCompras(montoTotalCompras)
        console.log(montoTotalC)
        setToLocalStorage("montoCompras", montoTotalCompras)
        return montoTotalCompras
    }

    const obtenerMontoVentas = () => {

        // console.log("Valor de cada compra ============> ")
        // listaCompras.map((compra) =>  console.log(compra.cantidad * compra.valor_actual))

        // filter((transaction) => transaction.tipo_operacion == 1 ? listaCompras.push(transaction) : null)

        let montoTotalVentas = listaVentas.reduce((acumulado, venta) => acumulado + (
            venta.cantidad * venta.valor_actual)

            , 0);
        console.log("El monto  total de VENTAS es:___________________")
        //  console.log(montoTotalCompras)
        setearMontoVentas(montoTotalVentas)
        console.log(montoTotalVentas)
        setToLocalStorage("montoVentas", montoTotalVentas)
        return montoTotalVentas
    }

    const obtenerMontoTotal = () => {
        // let montoParcialVentas = Number( listaVentas.reduce((acumulado, venta) => acumulado + (
        //     venta.cantidad * venta.valor_actual)))
        // let montoParcialCompras = Number( listaCompras.reduce((acumulado, compra) => acumulado + (
        //     compra.cantidad * compra.valor_actual)))
        let montoTotal = montoTotalC - montoTotalV
        setearMontoTotal(montoTotal)
        console.log("Monto Total es", montoTotal)
        setToLocalStorage("montoTotal", montoTotal)
    }


    useEffect(() => {
        try {
            transacciones.filter((transaction) => transaction.tipo_operacion == 1 ? listaCompras.push(transaction) : null)
            console.log("TRANSACCIONES COMPRAS = = = = = = = =")
            console.log(listaCompras)
            // console.log(listaCompras[1])
            transacciones.filter((transaction) => transaction.tipo_operacion == 2 ? listaVentas.push(transaction) : null)
            console.log("TRANSACCIONES Ventas = = = = = = = =")
            console.log(listaVentas)
            obtenerMontoCompras()
            obtenerMontoVentas()
            obtenerMontoTotal()


        } catch (error) {
            //   dispatch(setLogoutUser())
            console.log("Error en UseEffect que filtra compras y ventas")
        }
    }, [transacciones, listaCompras])





    // listaCompras = transacciones.filter((transaction) =>  transaction.tipo_operacion == 1)
    // console.log("TRANSACCIONES COMPRAS = = = = = = = =")
    // // transacciones.filter((transaction) => transaction.tipo_operacion == 1 ? listaCompras.push(transaction) : null)
    // // transacciones.filter((transaction) => transaction.tipo_operacion != 1 ? listaVentas.push(transaction) : null)
    // console.log(listaCompras)


    return (
        <div className="row justify-content-center">
            <h5 className="text-primary">Montos totales de Compras y Ventas en la cuenta</h5>
                <div class="card col col-sm-3 m-1 "  >
                        <h5 class="card-title">Monto total de compras</h5>
                        <p class="card-text">{montoTotalC}</p>
                </div>
              
                    <div class="card col col-sm-3 m-1">
                            <h5 class="card-title">Monto total de ventas</h5>
                            <p class="card-text">{montoTotalV}</p>
                    </div>
                  
                
                        <div class="card col col-sm-3 m-1" >
                                <h5 class="card-title">Monto total invertido</h5>
                                <p class="card-text">{montoTotalFinal}</p>
                        </div>
                       


        </div>
    )
}

export default TablaMontos