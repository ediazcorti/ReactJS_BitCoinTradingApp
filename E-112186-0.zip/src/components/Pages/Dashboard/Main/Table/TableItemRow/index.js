import TableItemRow from './TableItemRow';
export default TableItemRow;
