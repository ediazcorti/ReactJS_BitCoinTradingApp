import BarCompra from './BarCompra';
export default BarCompra;

