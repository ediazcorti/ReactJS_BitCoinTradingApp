import BarVenta from './BarVenta';
export default BarVenta;

