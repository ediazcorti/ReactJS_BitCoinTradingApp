import BarMoneda from './BarMoneda';
export default BarMoneda;
