import React from "react";

const CardMoneda = ({monedas, monedaId, tipoUltimaOperacion, valorUltTransacc, valorActualMoneda, recomendacion }) => { 

    const EncontrarNombreMoneda = (id) => {
        let moneda = monedas.listaMonedas.find(item => item.id === id)
        return moneda ? moneda.nombre : 0
      }

    return  (
        <div className="card m-20 p-20" >
     
    
      
    <h5 className="text-primary px-30">{EncontrarNombreMoneda(monedaId)}</h5>
     {/* <h5 class="card-title">ID Moneda: </h5>
     <p class="card-text">{monedaId} </p> */}

    <h6>Tipo de Última Operacion:</h6>
    {tipoUltimaOperacion == 1 ? "Compra" : "Venta"}
    <h6>Valor de la última transacción:</h6>
    <p class="card-text"> {valorUltTransacc}</p>
    <h6>Valor actual de esta Moneda:</h6>
    <p class="card-text">{valorActualMoneda}</p>
    <h6>La recomendación es:</h6>
    <p class="card-text">{recomendacion}</p>
  <br />
    
   

 
</div>

    
  
    )
}

export default CardMoneda