import React from 'react'

export default function ()  { 
return (

    <div>
        <h2>Footer 1</h2>
    </div>


 );

}